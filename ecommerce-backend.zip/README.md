# E-commerce Store API (Go + SQLite)

A runnable backend portfolio project for a Software Backend Intern role. It demonstrates REST APIs, Go, JSON, HTTP handlers, SQL persistence, validation, and basic inventory/cart operations.

## Requirements
- Go 1.22 or newer
- Internet access the first time Go downloads the SQLite driver

## Run locally
```bash
go mod tidy
go run .
```
The API starts at `http://localhost:8080`.

## Endpoints
- `GET /health` — health check
- `GET /products` — list products
- `POST /products` — create a product
- `GET /products/{id}` — product details
- `POST /cart` — add a product to cart
- `GET /cart` — view cart
- `DELETE /cart/{productID}` — remove a product from cart

## Example requests
Create a product:
```bash
curl -X POST http://localhost:8080/products -H "Content-Type: application/json" -d "{\"name\":\"Keyboard\",\"price\":799,\"stock\":10}"
```
Add product ID 1 to the cart:
```bash
curl -X POST http://localhost:8080/cart -H "Content-Type: application/json" -d "{\"product_id\":1,\"quantity\":2}"
```

## Notes
- SQLite database file `store.db` is created automatically.
- This is a learning/demo application, not a production payment system.
- No payment processing or user authentication is included.
- Review the code and be ready to explain it before using it in an interview.
