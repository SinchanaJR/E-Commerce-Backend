module ecommerce-backend

go 1.22

require modernc.org/sqlite v1.34.5
