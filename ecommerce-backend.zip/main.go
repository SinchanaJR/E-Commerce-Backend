package main

import (
	"database/sql"
	"encoding/json"
	"errors"
	"log"
	"net/http"
	"strconv"
	"strings"

	_ "modernc.org/sqlite"
)

type App struct{ db *sql.DB }
type Product struct {
	ID int64 `json:"id"`
	Name string `json:"name"`
	Price float64 `json:"price"`
	Stock int `json:"stock"`
}
type CartItem struct {
	ProductID int64 `json:"product_id"`
	Name string `json:"name"`
	Price float64 `json:"price"`
	Quantity int `json:"quantity"`
	Subtotal float64 `json:"subtotal"`
}
type addCartRequest struct {
	ProductID int64 `json:"product_id"`
	Quantity int `json:"quantity"`
}

func main() {
	db, err := sql.Open("sqlite", "store.db")
	if err != nil { log.Fatal(err) }
	defer db.Close()
	db.SetMaxOpenConns(1)
	if err := initDB(db); err != nil { log.Fatal(err) }
	app := &App{db: db}

	mux := http.NewServeMux()
	mux.HandleFunc("GET /health", app.health)
	mux.HandleFunc("GET /products", app.listProducts)
	mux.HandleFunc("POST /products", app.createProduct)
	mux.HandleFunc("GET /products/{id}", app.getProduct)
	mux.HandleFunc("POST /cart", app.addToCart)
	mux.HandleFunc("GET /cart", app.getCart)
	mux.HandleFunc("DELETE /cart/{productID}", app.removeFromCart)

	log.Println("E-commerce API running at http://localhost:8080")
	log.Fatal(http.ListenAndServe(":8080", cors(mux)))
}

func initDB(db *sql.DB) error {
	queries := []string{
		`CREATE TABLE IF NOT EXISTS products (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, price REAL NOT NULL CHECK(price >= 0), stock INTEGER NOT NULL CHECK(stock >= 0))`,
		`CREATE TABLE IF NOT EXISTS cart_items (product_id INTEGER PRIMARY KEY, quantity INTEGER NOT NULL CHECK(quantity > 0), FOREIGN KEY(product_id) REFERENCES products(id))`,
	}
	for _, q := range queries { if _, err := db.Exec(q); err != nil { return err } }
	var count int
	if err := db.QueryRow("SELECT COUNT(*) FROM products").Scan(&count); err != nil { return err }
	if count == 0 {
		_, err := db.Exec(`INSERT INTO products(name,price,stock) VALUES
			('Wireless Mouse',599,20),('Headphones',1299,15),('Notebook',149,100)`)
		return err
	}
	return nil
}
func (a *App) health(w http.ResponseWriter, r *http.Request) { writeJSON(w, 200, map[string]string{"status":"ok"}) }
func (a *App) listProducts(w http.ResponseWriter, r *http.Request) {
	rows, err := a.db.Query("SELECT id,name,price,stock FROM products ORDER BY id")
	if err != nil { serverError(w, err); return }
	defer rows.Close()
	items := []Product{}
	for rows.Next() { var p Product; if err := rows.Scan(&p.ID,&p.Name,&p.Price,&p.Stock); err != nil { serverError(w,err); return }; items=append(items,p) }
	writeJSON(w,200,items)
}
func (a *App) createProduct(w http.ResponseWriter, r *http.Request) {
	var p Product
	if err := decodeJSON(r,&p); err != nil { writeError(w,400,"Invalid JSON body"); return }
	p.Name = strings.TrimSpace(p.Name)
	if p.Name == "" || p.Price < 0 || p.Stock < 0 { writeError(w,400,"name is required; price and stock must be non-negative"); return }
	res, err := a.db.Exec("INSERT INTO products(name,price,stock) VALUES(?,?,?)",p.Name,p.Price,p.Stock)
	if err != nil { serverError(w,err); return }
	p.ID,_ = res.LastInsertId()
	writeJSON(w,201,p)
}
func (a *App) getProduct(w http.ResponseWriter, r *http.Request) {
	id, err := strconv.ParseInt(r.PathValue("id"),10,64)
	if err != nil || id < 1 { writeError(w,400,"Invalid product ID"); return }
	var p Product
	err = a.db.QueryRow("SELECT id,name,price,stock FROM products WHERE id=?",id).Scan(&p.ID,&p.Name,&p.Price,&p.Stock)
	if errors.Is(err,sql.ErrNoRows) { writeError(w,404,"Product not found"); return }
	if err != nil { serverError(w,err); return }
	writeJSON(w,200,p)
}
func (a *App) addToCart(w http.ResponseWriter, r *http.Request) {
	var req addCartRequest
	if err := decodeJSON(r,&req); err != nil { writeError(w,400,"Invalid JSON body"); return }
	if req.ProductID < 1 || req.Quantity < 1 || req.Quantity > 100 { writeError(w,400,"product_id must be positive and quantity must be between 1 and 100"); return }
	tx, err := a.db.Begin()
	if err != nil { serverError(w,err); return }
	defer tx.Rollback()
	var stock int
	if err := tx.QueryRow("SELECT stock FROM products WHERE id=?",req.ProductID).Scan(&stock); errors.Is(err,sql.ErrNoRows) { writeError(w,404,"Product not found"); return } else if err != nil { serverError(w,err); return }
	var current int
	err = tx.QueryRow("SELECT quantity FROM cart_items WHERE product_id=?",req.ProductID).Scan(&current)
	if err != nil && !errors.Is(err,sql.ErrNoRows) { serverError(w,err); return }
	if current+req.Quantity > stock { writeError(w,409,"Requested quantity exceeds available stock"); return }
	_, err = tx.Exec(`INSERT INTO cart_items(product_id,quantity) VALUES(?,?)
		ON CONFLICT(product_id) DO UPDATE SET quantity=quantity+excluded.quantity`,req.ProductID,req.Quantity)
	if err != nil { serverError(w,err); return }
	if err := tx.Commit(); err != nil { serverError(w,err); return }
	writeJSON(w,200,map[string]string{"message":"Item added to cart"})
}
func (a *App) getCart(w http.ResponseWriter, r *http.Request) {
	rows, err := a.db.Query(`SELECT p.id,p.name,p.price,c.quantity,p.price*c.quantity
		FROM cart_items c JOIN products p ON p.id=c.product_id ORDER BY p.name`)
	if err != nil { serverError(w,err); return }
	defer rows.Close()
	items := []CartItem{}
	total := 0.0
	for rows.Next() { var item CartItem; if err := rows.Scan(&item.ProductID,&item.Name,&item.Price,&item.Quantity,&item.Subtotal); err != nil { serverError(w,err); return }; items=append(items,item); total += item.Subtotal }
	writeJSON(w,200,map[string]any{"items":items,"total":total})
}
func (a *App) removeFromCart(w http.ResponseWriter, r *http.Request) {
	id, err := strconv.ParseInt(r.PathValue("productID"),10,64)
	if err != nil || id < 1 { writeError(w,400,"Invalid product ID"); return }
	res, err := a.db.Exec("DELETE FROM cart_items WHERE product_id=?",id)
	if err != nil { serverError(w,err); return }
	n,_ := res.RowsAffected()
	if n == 0 { writeError(w,404,"Cart item not found"); return }
	w.WriteHeader(http.StatusNoContent)
}
func decodeJSON(r *http.Request, dst any) error { defer r.Body.Close(); dec:=json.NewDecoder(r.Body); dec.DisallowUnknownFields(); return dec.Decode(dst) }
func writeJSON(w http.ResponseWriter, status int, v any) { w.Header().Set("Content-Type","application/json"); w.WriteHeader(status); _=json.NewEncoder(w).Encode(v) }
func writeError(w http.ResponseWriter, status int, message string) { writeJSON(w,status,map[string]string{"error":message}) }
func serverError(w http.ResponseWriter, err error) { log.Println(err); writeError(w,500,"Internal server error") }
func cors(next http.Handler) http.Handler { return http.HandlerFunc(func(w http.ResponseWriter,r *http.Request) { w.Header().Set("Access-Control-Allow-Origin","*"); w.Header().Set("Access-Control-Allow-Headers","Content-Type"); w.Header().Set("Access-Control-Allow-Methods","GET,POST,DELETE,OPTIONS"); if r.Method=="OPTIONS" { w.WriteHeader(204); return }; next.ServeHTTP(w,r) }) }
